Atlantic Launcher 2.0.0 — Low / Normal effects only
Normal uses the existing GTA/models baseline. Low uses modloader/AtlanticEffects_Low.
The High effects pack has been removed. Legacy High settings revert to Normal.
ModLoader is automatically enabled when Low is selected. Switching is applied before starting GTA.
Original engine documentation and licenses remain under modloader/.data.
